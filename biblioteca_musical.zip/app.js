const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.static('public'));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(express.json());

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const genre = req.body.genre;
    const band = req.body.band;
    const dir = path.join(__dirname, 'uploads', genre, band);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

app.post('/upload', upload.single('audio'), (req, res) => {
  if (!req.file || !req.body.genre || !req.body.band) {
    return res.status(400).json({ error: 'Dados incompletos' });
  }
  res.json({ success: true, path: req.file.path });
});

app.get('/musics', (req, res) => {
  const base = path.join(__dirname, 'uploads');
  const musicData = {};

  if (!fs.existsSync(base)) return res.json(musicData);

  fs.readdirSync(base).forEach(genre => {
    musicData[genre] = {};
    const genrePath = path.join(base, genre);
    fs.readdirSync(genrePath).forEach(band => {
      const bandPath = path.join(genrePath, band);
      const songs = fs.readdirSync(bandPath).map(file => ({
        name: file,
        url: `/uploads/${genre}/${band}/${file}`
      }));
      musicData[genre][band] = songs;
    });
  });

  res.json(musicData);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`Servidor rodando na porta ${PORT}`));
