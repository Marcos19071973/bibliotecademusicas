# Biblioteca Musical

### Como rodar localmente:

1. Instale o Node.js (https://nodejs.org)
2. No terminal, vá até a pasta do projeto e rode:

```
npm install
npm start
```

3. Acesse em: http://localhost:3000

### Como hospedar online:
- Pode usar serviços como Render.com, Replit, ou outro VPS
- Certifique-se que a porta usada é `process.env.PORT` (já está configurado)

Arquivos são salvos em `uploads/<gênero>/<banda>/`.

Frontend acessa músicas reais e exibe por abas de gênero/banda.
